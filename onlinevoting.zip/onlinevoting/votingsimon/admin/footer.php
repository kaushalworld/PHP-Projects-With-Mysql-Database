
<footer class="footer">
	<hr/>
&copy2018. Developed by SIMON MUTUKU : 89038.
<br/>
Online Voting System.
<br/>
Final Year Project 2019. STRATHMORE UNIVERSITY
<br/>
Contact: <a href="tel:+254704689286">+254704689286</a> | Email: <a href="mailto:simon.mutuku@strathmore.edu">simon.mutuku@strathmore.edu</a>

</footer>
