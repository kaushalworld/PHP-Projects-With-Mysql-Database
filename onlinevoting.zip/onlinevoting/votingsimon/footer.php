
<footer class="footer">
	<hr/>
&copy2019. Developed by SIMON MUTUKU : 089038.
<br/>
 Nafaka Sacco Online Voting System.
<br/>
Final Year Project 2019. STRATHMORE UNIVERSITY 
<br/>
Contact: <a href="tel:+254704689286">+2547-146-43906</a> | Email: <a href="mailto:simon.mutuku @strathmore.edu">simon.mutuku @strathmore.edu</a>

</footer>
