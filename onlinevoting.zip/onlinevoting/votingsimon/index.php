<?php include ('head.php');?>

<body>
	<?php include ('view_banner.php');?>

    <heading class="voters_heading">
        <center><h1>NAFAKA SACCO</h1>
    </heading>
    <?php include 'slider.php';?>
    <div class="image">
    	<img src="img/img1.jpg" width="40%" hieght="40%"/>
    </div>
    <div class="union-infor">
    Where Sacco members bring union during election by voting wisely to elect the best leaders.
    </div>


    <?php    
        include ('footer.php');
        ?>

   </body>
</html>

