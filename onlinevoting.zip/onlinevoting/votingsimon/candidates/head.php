<!DOCTYPE html>
<!--
Author: ELIAS NGUMBI
Contact Detailes: 0714 - 643906
Email: eliasngumbi54@gmail.com
Date: 11 - 04 - 2019
Fina Year Project - Bachelor of Business Information Technology
Murang'a University of Technology
Online Voting System

-->
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Onlive-Voting</title>
    <link rel="stylesheet" type="text/css" href="css/myStlyes.css">
    <link  rel="icon" href="img/12.png">
    	   <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Default Layout -->
	<link href="css/style.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
	
</head
<?php
include ('script.php');
?>