
<footer class="footer">
	<hr/>
&copy2018. Developed by Elias Ngumbi : BE232/0059/2015.
<br/>
Online Voting System.
<br/>
Final Year Project 2018. Murang'a University of Technology
<br/>
Contact: <a href="tel:+25414643906">+254714643906</a> | Email: <a href="mailto:eliasngumbi54@gmail.com">eliasngumbi54@gmail.com</a>

</footer>
