 <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-home"></i>
            <span>Home</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="examsched.php">
            <i class="fas fa-fw fa-calendar"></i>
            <span>Exam Schedule</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="examinee.php">
            <i class="fas fa-fw fa-users"></i>
            <span>Registered Examinee's</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="sum.php">
            <i class="fas fa-fw fa-list"></i>
            <span>Summary</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="summary.php">
            <i class="fas fa-fw fa-list"></i>
            <span>Report</span>
          </a>
        </li>
        <li class="nav-item dropdown active">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-cog"></i>
            <span>Maintainance</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">Settings:</h6>
            <a class="dropdown-item fas fa-percentage" href="creteria.php">Criteria</a>
            <a class="dropdown-item fas fa-calendar-alt" href="schoolyear.php">School Year</a>
           <a class="dropdown-item fas fa-lightbulb" href="key.php">Answer Key</a>
           
          </div>
        </li>
        <!-- <li class="nav-item active">
          <a class="nav-link" href="manageexam.php">
            <i class="fas fa-fw fa-key"></i>
            </a>
        </li> -->
      </ul>