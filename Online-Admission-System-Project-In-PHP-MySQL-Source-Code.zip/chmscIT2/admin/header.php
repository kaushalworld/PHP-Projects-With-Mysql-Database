<body>
<style>

    /* Optional: Makes the sample page fill the window. */
 /* Always set the map height explicitly to define the size of the div
 * element that contains the map. */
    #map {
        height: 90%;
        width: 100%;
        float: right;
        margin-top: 5px;

    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

