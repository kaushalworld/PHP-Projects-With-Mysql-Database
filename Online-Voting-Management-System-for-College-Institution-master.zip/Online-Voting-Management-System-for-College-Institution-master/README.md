# Online-Voting-Management-System-for-College-Institution
This is an online voting platform where Voters login to vote for their candidates depending on the Organization. The system now works with PHP 7.

HOW IT WORKS:-
– Admin adds an Organization e.g Harvard Campus Election.
– Admin then adds the Positions in that Organization.
– Admin then adds Nominees for those Positions
– Then the Voters vote.

VOTING PLATFORM FEATURES:-
No Errors.
Clean URLs
Great Design both frontend and Backend.
Forgot Password email notification

ADMIN LOGIN CREDENTIALS:-
Login ID : admin
Username :- Admin01
Password :- 12345
