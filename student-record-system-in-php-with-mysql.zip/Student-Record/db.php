<?php
$con = mysqli_connect('localhost','root','','student_card');
if($con){
	
}else{
	echo "Not Connected";
}

?>