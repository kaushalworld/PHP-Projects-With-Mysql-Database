Software Requirements:

Operating System: Windows Family.
Application Server :    XAMPP
Web designing languages :  HTML, CSS.
Scripts: JavaScript.
Server-side Script: PHP.
Database:   Mysql
Database Connectivity :   PhpMyAdmin.

WhatsApp Number: +919753531615