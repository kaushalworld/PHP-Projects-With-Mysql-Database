<footer class="footer text-right">
   <?php echo date('Y'); ?> © Developed by <a href="https://www.projecto.in/">Projecto</a>
</footer>