            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                            <li class="menu-title">Navigation</li>
                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-speedometer"></i> <span> Dashboard </span> </a>
                            </li>
                            <li class="has_sub">
                                <a href="new-visitor.php" class="waves-effect"><i class="mdi mdi-plus m-r-13"></i> <span> New Vistor </span></a>
                            </li>
                            
                            <li class="has_sub">
                                <a href="manage-visitor.php" class="waves-effect"><i class="mdi mdi-pencil-box-outline m-r-13"></i> <span>Manage Vistor </span></a>
                            </li>
                            <li class="has_sub">
                                <a href="logout.php" class="waves-effect"><i class="ti-power-off m-r-13"></i> <span> Logout </span></a>
                            </li>
                        </ul>
                    </div>
                    <!-- Sidebar -->


                </div>
                <!-- Sidebar -left -->

            </div>