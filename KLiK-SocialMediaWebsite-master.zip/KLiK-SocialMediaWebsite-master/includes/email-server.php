<?php

$SMTPuser = 'klik.official.website@gmail.com';   
$SMTPpwd = 'dingydingdong69dingydong'; 
$SMTPtitle = "KLiK inc.";
$Domain = 'localhost';

