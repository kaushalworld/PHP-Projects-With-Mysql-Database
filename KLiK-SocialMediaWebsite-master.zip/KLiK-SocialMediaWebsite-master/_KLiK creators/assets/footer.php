
<br><br><br><br>
<footer id="myFooter" class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h2 class="logo"><a href="../index.php"><img src='../img/200.png'></a></h2>
                </div>
                <div class="col-sm-2">
                    <h5>Get started</h5>
                    <ul>
                        <li><a href="../index.php">Home</a></li><br>
                        <li><a href="../team.php">The Team</a></li><br>
                        <li><a href="../forum.php">The KLiK Forum</a></li><br>
                        <li><a href="../hub.php">The KLiK Hub</a></li><br>
                    </ul>
                </div>
                <div class="col-sm-2">
                    <h5>About us</h5>
                    <ul>
                        <li><a href="klik_saad.php">Muhammad Saad</a></li>
                        <li><a href="klik_anas-imran.php">Anas Imran</a></li>
                        <li><a href="klik_anas-kamal.php">Anas Kamal</a></li>
                        <li><a href="klik_ubaid.php">Ubaid Asim</a></li>
                    </ul>
                </div>
                <div class="col-sm-2">
                    <h5>Support</h5>
                    <ul>
                        <li><a href="../contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <div class="social-networks">
                        <a href="https://github.com/msaad1999/KLiK--PHP-coded-Social-Media-Website" 
                           class="twitter"><i class="fa fa-github fa-2x"></i></a>
                    </div>
                    <a class="btn btn-default" href="../contact.php">Contact us</a>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> All Rights Reserved </p>
        </div>
    </footer>